'use client'

import { useEffect, useState } from 'react';
import { Calendar, Badge, Button, Modal, Form, Input, TimePicker, Select, message } from 'antd';
import { Api, Model } from '@web/domain';
import dayjs from 'dayjs';

export default function CalendarPage() {
  const [reservations, setReservations] = useState<Model.Reservation[]>([]);
  const [spaces, setSpaces] = useState<Model.Space[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form] = Form.useForm();

  useEffect(() => {
    async function fetchReservations() {
      try {
        const data = await Api.Reservation.findMany({
          includes: ['user', 'space']
        });
        setReservations(data);
      } catch (error) {
        console.error('Failed to fetch reservations:', error);
      }
    }

    async function fetchSpaces() {
      try {
        const data = await Api.Space.findMany();
        setSpaces(data);
      } catch (error) {
        console.error('Failed to fetch spaces:', error);
      }
    }

    fetchReservations();
    fetchSpaces();
  }, []);

  const dateCellRender = (value: dayjs.Dayjs) => {
    const listData = reservations.filter(reservation =>
      dayjs(reservation.startTime).isSame(value, 'day')
    );

    return (
      <ul className="events">
        {listData.map(item => (
          <li key={item.id}>
            <Badge 
              status="success" 
              text={`${dayjs(item.startTime).format('DD/MM/YYYY H:mm')} - ${dayjs(item.endTime).format('DD/MM/YYYY H:mm')} | ${item.space?.name} | ${item.user?.name}`} 
            />
          </li>
        ))}
      </ul>
    );
  };

  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    form.resetFields();
  };

  const handleFormSubmit = async (values: any) => {
    try {
      const newReservation = await Api.Reservation.create({
        startTime: values.startTime.format(),
        endTime: values.endTime.format(),
        spaceId: values.spaceId,
        userId: 'currentUserId' // Replace with actual user ID
      });

      setReservations([...reservations, newReservation]);
      message.success('Reservation created successfully!');
      handleCloseModal();
    } catch (error) {
      console.error('Failed to create reservation:', error);
      message.error('Failed to create reservation.');
    }
  };

  return (
    <div>
      <Button type="primary" onClick={handleOpenModal}>
        Make a Reservation
      </Button>
      <Calendar dateCellRender={dateCellRender} />
      <Modal
        title="Make a Reservation"
        visible={isModalOpen}
        onCancel={handleCloseModal}
        footer={null}
      >
        <Form form={form} onFinish={handleFormSubmit}>
          <Form.Item
            name="startTime"
            label="Start Time"
            rules={[{ required: true, message: 'Please select start time' }]}
          >
            <TimePicker format="HH:mm" />
          </Form.Item>
          <Form.Item
            name="endTime"
            label="End Time"
            rules={[{ required: true, message: 'Please select end time' }]}
          >
            <TimePicker format="HH:mm" />
          </Form.Item>
          <Form.Item
            name="spaceId"
            label="Space"
            rules={[{ required: true, message: 'Please select a space' }]}
          >
            <Select>
              {spaces.map(space => (
                <Select.Option key={space.id} value={space.id}>
                  {space.name}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
