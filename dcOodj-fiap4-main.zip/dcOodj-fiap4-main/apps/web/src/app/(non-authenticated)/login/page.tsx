'use client'

import { RouterObject } from '@web/core/router'
import { useCoreStore } from '@web/core/store'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { Flex, Typography } from 'antd'
const { Text } = Typography

export default function LoginPage() {
  const router = useRouter()

  useEffect(() => {
    router.push(RouterObject.route.HOME)
  }, [])

  return (
    <Flex align="center" justify="center" vertical flex={1}>
      <Text>Redirecting to home...</Text>
    </Flex>
  )
}
